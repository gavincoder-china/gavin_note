Please read Wiki carefully, especially / 提问前请先阅读wiki https://github.com/shadowsocks/shadowsocks-windows/wiki/Troubleshooting.
Or search from issue board / 或在issue board中搜索 https://github.com/shadowsocks/shadowsocks-windows/issues?utf8=%E2%9C%93&q=is%3Aissue
Please answer these questions before submitting your issue. Thanks! / 请按照以下格式描述你的问题

### Version(release version or AppVeyor link) / 版本（正式版或基于AppVeyor的链接）


### Environment(Operating system, .NET Framework, etc) / 操作环境（操作系统，.NET Framework等）


### Steps you have tried / 操作步骤


### What did you expect to see? / 期望的结果


### What did you see instead? / 实际结果


### Config and error log in detail (with all sensitive info masked) / 配置文件和日志文件（请隐去敏感信息）