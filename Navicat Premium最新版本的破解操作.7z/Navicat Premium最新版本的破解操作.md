# Navicat Premium最新版本的破解操作

在网上找了很多的破解注册机等玩具，到最后，发现还是这个东西好用。    

![](https://raw.githubusercontent.com/xunyegege/picgo_repo/master/G%3A%5Cgithub%5Cpicgo_repo20181010190855.png)

 这个文件我上传到我的github上，大家免费获取  

github地址为https://github.com/xunyegege/gavin_note

## 破解流程 

网上很多的操作，都比较神奇，反正我是看不懂。

只好自己写个了。  

### 第一步

打开cmd

### 第二步

![](https://raw.githubusercontent.com/xunyegege/picgo_repo/master/G%3A%5Cgithub%5Cpicgo_repo20181010191235.png)

看我这边的地址是 C:\Users\Administrator

所以将破解包里的三个文件全部放到这个文件夹下

### 第三步

在cmd中输入这个

`navicat-patcher.exe ``"C:\Program Files\PremiumSoft\Navicat Premium 12"` `RegPrivateKey.pem`

**中间那个是你的文件安装地址，你要按照自己的安装路径来写 **

### 第四步

在cmd中输入

navicat-keygen.exe RegPrivateKey.pem

你会被要求选择Navicat产品类别、语言以及输入主版本号

![](https://raw.githubusercontent.com/xunyegege/picgo_repo/master/G%3A%5Cgithub%5Cpicgo_repo20181010191744.png)

这边你们每个人按照自己需求填写 

最后会给你个激活码，你复制一下

下面还会让你填name跟Organization ，

你直接填 gavincoder 跟alibaba就行



### 第五步

现在你需要断网，然后打开软件，输入激活码

软件会提示你手动激活 

点开手动激活

他会出现个请求码，你复制到cmd里面 

然后cmd里就会出现一串激活码

你复制到软件里就好了。

这边因为我已经激活好了，就不再放图了。  



这下就好了，有不懂的可以联系我vx：xunyegege

